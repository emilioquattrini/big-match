# BIG MATCH

Interactive web experience for Chiara Zhu / Impersonae at BIG Milano 2026.

## GitHub Pages

This repository is ready to be published with GitHub Pages.

1. Open **Settings → Pages**
2. Under **Build and deployment**, choose **Deploy from a branch**
3. Select `main` and `/ (root)`
4. Save

The application entry point is `index.html`.

## Current build

Safari/WebKit-oriented build using CSS `background-image` for the Impersonae cards rather than dynamic `<img>` card elements.
